-- LUKAS: skema, RLS, dan RPC transaksi keuangan
create extension if not exists pgcrypto;
create type user_role as enum ('admin','bendahara','siswa');
create type tx_type as enum ('masuk','keluar');
create type expense_status as enum ('menunggu_persetujuan','perlu_revisi','disetujui','ditolak','menunggu_bukti','selesai');

create table classes (
  id uuid primary key default gen_random_uuid(),
  name text not null, school_year text not null,
  opening_balance numeric(14,2) not null default 0 check (opening_balance >= 0),
  is_demo boolean not null default false, created_at timestamptz not null default now());

create table profiles (
  id uuid primary key references auth.users on delete cascade,
  class_id uuid references classes, full_name text not null,
  username text unique, role user_role not null default 'siswa',
  can_announce boolean not null default false, is_active boolean not null default true,
  created_at timestamptz not null default now());

create table students (
  id uuid primary key default gen_random_uuid(),
  class_id uuid not null references classes, profile_id uuid unique references profiles,
  full_name text not null, absen_no int not null, nis text,
  is_active boolean not null default true, is_demo boolean not null default false,
  joined_at date not null default current_date, created_at timestamptz not null default now(),
  unique (class_id, absen_no));

create table cash_schedules (
  id uuid primary key default gen_random_uuid(),
  class_id uuid not null references classes, name text not null,
  amount numeric(14,2) not null check (amount > 0),
  frequency text not null check (frequency in ('harian','mingguan','bulanan')),
  pay_day int, start_date date not null, end_date date, due_date date,
  is_demo boolean not null default false, created_at timestamptz not null default now());

create table cash_payments (
  id uuid primary key default gen_random_uuid(),
  code text not null unique, class_id uuid not null references classes,
  student_id uuid not null references students, schedule_id uuid references cash_schedules,
  period text not null, amount numeric(14,2) not null check (amount > 0),
  method text not null check (method in ('tunai','transfer','lainnya')),
  paid_on date not null default current_date, note text, proof_path text,
  recorded_by uuid not null references profiles, is_demo boolean not null default false,
  created_at timestamptz not null default now());
create unique index uq_payment_period on cash_payments (student_id, schedule_id, period);

create table expense_requests (
  id uuid primary key default gen_random_uuid(),
  class_id uuid not null references classes, item_name text not null,
  category text not null, reason text not null,
  estimated_amount numeric(14,2) not null check (estimated_amount > 0),
  approved_amount numeric(14,2), actual_amount numeric(14,2) check (actual_amount > 0),
  status expense_status not null default 'menunggu_persetujuan',
  buyer_name text, store text, purchase_date date, receipt_path text, note text,
  requested_by uuid not null references profiles, reviewed_by uuid references profiles,
  review_note text, published boolean not null default false,
  is_demo boolean not null default false, created_at timestamptz not null default now(),
  check (reviewed_by is null or reviewed_by <> requested_by));

create table expense_status_history (
  id uuid primary key default gen_random_uuid(),
  expense_id uuid not null references expense_requests on delete cascade,
  from_status expense_status, to_status expense_status not null,
  changed_by uuid not null references profiles, note text, created_at timestamptz not null default now());

create table cash_transactions (
  id uuid primary key default gen_random_uuid(),
  code text not null unique, class_id uuid not null references classes,
  type tx_type not null, amount numeric(14,2) not null check (amount > 0),
  category text, description text,
  payment_id uuid references cash_payments, expense_id uuid references expense_requests,
  reverses_id uuid references cash_transactions, reason text,
  check (reverses_id is null or reason is not null),
  created_by uuid not null references profiles, is_demo boolean not null default false,
  created_at timestamptz not null default now());
create index on cash_transactions (class_id, created_at desc);

create table announcements (
  id uuid primary key default gen_random_uuid(), class_id uuid not null references classes,
  title text not null, body text not null, category text, attachment_path text,
  published boolean not null default false, created_by uuid not null references profiles,
  is_demo boolean not null default false, created_at timestamptz not null default now());

create table notifications (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references profiles on delete cascade,
  title text not null, body text, is_read boolean not null default false,
  created_at timestamptz not null default now());
create index on notifications (user_id, is_read);

create table activity_logs (
  id uuid primary key default gen_random_uuid(), class_id uuid references classes,
  user_id uuid references profiles, action text not null,
  before_data jsonb, after_data jsonb, note text, created_at timestamptz not null default now());

create table class_votes (
  id uuid primary key default gen_random_uuid(), class_id uuid not null references classes,
  title text not null, starts_at timestamptz not null, ends_at timestamptz not null check (ends_at > starts_at),
  created_by uuid not null references profiles, is_demo boolean not null default false);
create table vote_options (
  id uuid primary key default gen_random_uuid(), vote_id uuid not null references class_votes on delete cascade, label text not null);
create table vote_responses (
  id uuid primary key default gen_random_uuid(), vote_id uuid not null references class_votes on delete cascade,
  option_id uuid not null references vote_options, user_id uuid not null references profiles,
  created_at timestamptz not null default now(), unique (vote_id, user_id));

-- Helper
create function auth_role() returns user_role language sql stable security definer set search_path=public as
$$ select role from profiles where id = auth.uid() and is_active $$;
create function auth_class() returns uuid language sql stable security definer set search_path=public as
$$ select class_id from profiles where id = auth.uid() and is_active $$;
create function gen_code(prefix text) returns text language sql as
$$ select prefix||'-'||to_char(now(),'YYMMDD')||'-'||upper(substr(md5(random()::text||clock_timestamp()::text),1,6)) $$;
create function class_balance(cid uuid) returns numeric language sql stable security definer set search_path=public as
$$ select c.opening_balance
   + coalesce((select sum(amount) from cash_transactions where class_id=cid and type='masuk'),0)
   - coalesce((select sum(amount) from cash_transactions where class_id=cid and type='keluar'),0)
   from classes c where c.id=cid and cid = auth_class() $$;
create function log_activity(cid uuid, act text, bef jsonb, aft jsonb, nt text) returns void
language sql security definer set search_path=public as
$$ insert into activity_logs(class_id,user_id,action,before_data,after_data,note) values (cid,auth.uid(),act,bef,aft,nt) $$;

-- Transaksi tidak boleh diubah/dihapus (koreksi = transaksi pembalik)
create function block_mutation() returns trigger language plpgsql as
$$ begin raise exception 'Transaksi tidak dapat diubah atau dihapus; buat koreksi.'; end $$;
create trigger trg_tx_immutable before update or delete on cash_transactions for each row execute function block_mutation();

-- RLS
do $$ declare t text; begin
  for t in select unnest(array['classes','profiles','students','cash_schedules','cash_payments','expense_requests','expense_status_history',
    'cash_transactions','announcements','notifications','activity_logs','class_votes','vote_options','vote_responses'])
  loop execute format('alter table %I enable row level security', t); end loop; end $$;

create policy classes_r on classes for select using (id = auth_class());
create policy profiles_r on profiles for select using (id = auth.uid() or (class_id = auth_class() and auth_role() in ('admin','bendahara')));
create policy students_r on students for select using (class_id = auth_class() and (auth_role() in ('admin','bendahara') or profile_id = auth.uid()));
create policy students_w on students for all using (class_id = auth_class() and auth_role()='admin') with check (class_id = auth_class() and auth_role()='admin');
create policy sched_r on cash_schedules for select using (class_id = auth_class());
create policy sched_w on cash_schedules for all using (class_id = auth_class() and auth_role()='admin') with check (class_id = auth_class() and auth_role()='admin');
create policy pay_r on cash_payments for select using (class_id = auth_class() and (auth_role() in ('admin','bendahara')
  or student_id in (select id from students where profile_id = auth.uid())));
create policy exp_r on expense_requests for select using (class_id = auth_class() and (auth_role() in ('admin','bendahara') or (published and status='selesai')));
create policy hist_r on expense_status_history for select using (auth_role() in ('admin','bendahara')
  and expense_id in (select id from expense_requests where class_id = auth_class()));
create policy tx_r on cash_transactions for select using (class_id = auth_class());
create policy ann_r on announcements for select using (class_id = auth_class() and (published or auth_role() in ('admin','bendahara')));
create policy ann_w on announcements for all using (class_id = auth_class() and (auth_role()='admin' or (auth_role()='bendahara' and exists(select 1 from profiles where id=auth.uid() and can_announce))))
  with check (class_id = auth_class() and (auth_role()='admin' or (auth_role()='bendahara' and exists(select 1 from profiles where id=auth.uid() and can_announce))));
create policy notif_r on notifications for select using (user_id = auth.uid());
create policy notif_u on notifications for update using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy log_r on activity_logs for select using (class_id = auth_class() and auth_role()='admin');
create policy vote_r on class_votes for select using (class_id = auth_class());
create policy vote_w on class_votes for all using (class_id = auth_class() and auth_role() in ('admin','bendahara')) with check (class_id = auth_class() and auth_role() in ('admin','bendahara'));
create policy opt_r on vote_options for select using (vote_id in (select id from class_votes where class_id = auth_class()));
create policy opt_w on vote_options for all using (auth_role() in ('admin','bendahara') and vote_id in (select id from class_votes where class_id = auth_class()))
  with check (auth_role() in ('admin','bendahara') and vote_id in (select id from class_votes where class_id = auth_class()));
create policy resp_r on vote_responses for select using (vote_id in (select id from class_votes where class_id = auth_class()));
create policy resp_i on vote_responses for insert with check (user_id = auth.uid() and exists(
  select 1 from class_votes v where v.id = vote_id and v.class_id = auth_class() and now() between v.starts_at and v.ends_at));
-- Tidak ada policy INSERT/UPDATE/DELETE langsung pada tabel keuangan: semua lewat RPC di bawah.

-- RPC: catat pembayaran siswa (atomik)
create function record_payment(p_student uuid, p_schedule uuid, p_period text, p_amount numeric, p_method text,
  p_date date default current_date, p_note text default null, p_proof text default null)
returns uuid language plpgsql security definer set search_path=public as $$
declare cid uuid := auth_class(); pid uuid; begin
  if auth_role() not in ('admin','bendahara') then raise exception 'Tidak diizinkan'; end if;
  if p_amount is null or p_amount <= 0 then raise exception 'Nominal harus lebih dari 0'; end if;
  perform 1 from classes where id = cid for update;
  if not exists (select 1 from students where id = p_student and class_id = cid and is_active) then raise exception 'Siswa tidak valid'; end if;
  insert into cash_payments(code,class_id,student_id,schedule_id,period,amount,method,paid_on,note,proof_path,recorded_by)
    values (gen_code('PAY'),cid,p_student,p_schedule,p_period,p_amount,p_method,p_date,p_note,p_proof,auth.uid()) returning id into pid;
  insert into cash_transactions(code,class_id,type,amount,category,description,payment_id,created_by)
    values (gen_code('TRX'),cid,'masuk',p_amount,'Kas siswa','Pembayaran kas '||p_period,pid,auth.uid());
  perform log_activity(cid,'pemasukan',null,jsonb_build_object('payment_id',pid,'amount',p_amount),p_note);
  return pid; end $$;

-- RPC: bendahara mengajukan pengeluaran (tidak mengurangi saldo)
create function submit_expense(p_item text, p_category text, p_reason text, p_estimate numeric)
returns uuid language plpgsql security definer set search_path=public as $$
declare cid uuid := auth_class(); eid uuid; begin
  if auth_role() not in ('admin','bendahara') then raise exception 'Tidak diizinkan'; end if;
  insert into expense_requests(class_id,item_name,category,reason,estimated_amount,requested_by)
    values (cid,p_item,p_category,p_reason,p_estimate,auth.uid()) returning id into eid;
  insert into expense_status_history(expense_id,to_status,changed_by) values (eid,'menunggu_persetujuan',auth.uid());
  insert into notifications(user_id,title,body) select id,'Pengajuan baru',p_item from profiles where class_id=cid and role='admin';
  perform log_activity(cid,'pengajuan_pengeluaran',null,jsonb_build_object('expense_id',eid),p_item);
  return eid; end $$;

-- RPC: admin memutuskan pengajuan (tidak boleh menyetujui pengajuan sendiri)
create function review_expense(p_id uuid, p_decision text, p_amount numeric default null, p_note text default null)
returns void language plpgsql security definer set search_path=public as $$
declare e expense_requests; ns expense_status; begin
  if auth_role() <> 'admin' then raise exception 'Hanya admin'; end if;
  select * into e from expense_requests where id = p_id and class_id = auth_class() for update;
  if not found then raise exception 'Pengajuan tidak ditemukan'; end if;
  if e.requested_by = auth.uid() then raise exception 'Tidak boleh menyetujui pengajuan sendiri'; end if;
  if e.status <> 'menunggu_persetujuan' then raise exception 'Status tidak dapat direview'; end if;
  ns := case p_decision when 'setuju' then 'menunggu_bukti' when 'tolak' then 'ditolak' when 'revisi' then 'perlu_revisi'
        else null end;
  if ns is null then raise exception 'Keputusan tidak valid'; end if;
  update expense_requests set status = ns, reviewed_by = auth.uid(), review_note = p_note,
    approved_amount = case when ns='menunggu_bukti' then coalesce(p_amount, estimated_amount) end where id = p_id;
  insert into expense_status_history(expense_id,from_status,to_status,changed_by,note) values (p_id,e.status,ns,auth.uid(),p_note);
  insert into notifications(user_id,title,body) values (e.requested_by,'Pengajuan '||p_decision,e.item_name);
  perform log_activity(e.class_id,'review_pengeluaran',to_jsonb(e),jsonb_build_object('status',ns),p_note); end $$;

-- RPC: selesaikan pengeluaran dengan nominal aktual + nota
create function complete_expense(p_id uuid, p_actual numeric, p_receipt text, p_store text, p_buyer text, p_date date)
returns void language plpgsql security definer set search_path=public as $$
declare e expense_requests; cid uuid := auth_class(); begin
  if auth_role() not in ('admin','bendahara') then raise exception 'Tidak diizinkan'; end if;
  perform 1 from classes where id = cid for update;
  select * into e from expense_requests where id = p_id and class_id = cid for update;
  if not found or e.status <> 'menunggu_bukti' then raise exception 'Pengajuan belum disetujui'; end if;
  if p_actual is null or p_actual <= 0 then raise exception 'Nominal aktual tidak valid'; end if;
  if p_receipt is null or p_receipt = '' then raise exception 'Nota wajib diunggah'; end if;
  if p_actual > e.approved_amount then
    update expense_requests set status='menunggu_persetujuan', actual_amount=p_actual, receipt_path=p_receipt,
      review_note='Nominal aktual melebihi persetujuan; butuh persetujuan ulang' where id = p_id;
    insert into expense_status_history(expense_id,from_status,to_status,changed_by,note) values (p_id,e.status,'menunggu_persetujuan',auth.uid(),'Melebihi nominal disetujui');
    return; end if;
  if class_balance(cid) < p_actual then raise exception 'Saldo tidak mencukupi'; end if;
  update expense_requests set status='selesai', actual_amount=p_actual, receipt_path=p_receipt, store=p_store,
    buyer_name=p_buyer, purchase_date=p_date, published=true where id = p_id;
  insert into cash_transactions(code,class_id,type,amount,category,description,expense_id,created_by)
    values (gen_code('TRX'),cid,'keluar',p_actual,e.category,e.item_name,p_id,auth.uid());
  insert into expense_status_history(expense_id,from_status,to_status,changed_by) values (p_id,e.status,'selesai',auth.uid());
  perform log_activity(cid,'pengeluaran_selesai',null,jsonb_build_object('expense_id',p_id,'amount',p_actual),null); end $$;

-- RPC: koreksi transaksi (admin) = transaksi pembalik + alasan
create function correct_transaction(p_id uuid, p_reason text) returns void
language plpgsql security definer set search_path=public as $$
declare t cash_transactions; begin
  if auth_role() <> 'admin' then raise exception 'Hanya admin'; end if;
  if coalesce(trim(p_reason),'') = '' then raise exception 'Alasan wajib diisi'; end if;
  perform 1 from classes where id = auth_class() for update;
  select * into t from cash_transactions where id = p_id and class_id = auth_class();
  if not found or t.reverses_id is not null or exists(select 1 from cash_transactions where reverses_id = p_id) then raise exception 'Transaksi tidak dapat dikoreksi'; end if;
  if t.type = 'masuk' and class_balance(t.class_id) < t.amount then raise exception 'Saldo tidak mencukupi untuk koreksi'; end if;
  insert into cash_transactions(code,class_id,type,amount,category,description,reverses_id,reason,created_by)
    values (gen_code('COR'),t.class_id,case t.type when 'masuk' then 'keluar'::tx_type else 'masuk'::tx_type end,
      t.amount,t.category,'Koreksi '||t.code,t.id,p_reason,auth.uid());
  perform log_activity(t.class_id,'koreksi_transaksi',to_jsonb(t),null,p_reason); end $$;

grant execute on function record_payment, submit_expense, review_expense, complete_expense, correct_transaction, class_balance to authenticated;

-- Storage privat untuk bukti (path: <class_id>/<nama-file>)
insert into storage.buckets (id, name, public) values ('receipts','receipts',false) on conflict do nothing;
create policy receipts_r on storage.objects for select using (bucket_id='receipts' and (storage.foldername(name))[1] = auth_class()::text);
create policy receipts_w on storage.objects for insert with check (bucket_id='receipts' and auth_role() in ('admin','bendahara') and (storage.foldername(name))[1] = auth_class()::text);
